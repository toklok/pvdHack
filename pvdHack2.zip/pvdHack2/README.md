# pvdHack
Providence, RI Pot hole killer

traffic data from waze API

JSON objects containing "subtype": "HAZARD_ON_ROAD_POT_HOLE"

storing data???

map created using leaflet and geoJSON objects

Providence Ward Polygons from Providence Open Data

INSTALL
=======

+ npm install -g webpack
+ npm install -g webpack-dev-server
+ npm install

+ npm start
+ npm watch
